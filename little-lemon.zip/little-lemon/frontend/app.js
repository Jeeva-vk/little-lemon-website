// Fetch menu data from the server
document.addEventListener('DOMContentLoaded', () => {
    fetchMenu();
  
    // Handle reservation form submission
    const reservationForm = document.getElementById('reservation-form');
    reservationForm.addEventListener('submit', handleReservation);
  });
  
  function fetchMenu() {
    fetch('/api/menu')
      .then(response => response.json())
      .then(menu => {
        const menuItemsContainer = document.getElementById('menu-items');
        menuItemsContainer.innerHTML = '';
        menu.forEach(item => {
          const menuItemDiv = document.createElement('div');
          menuItemDiv.classList.add('menu-item');
          menuItemDiv.innerHTML = `
            <h3>${item.name}</h3>
            <p>${item.description}</p>
            <p><strong>$${item.price.toFixed(2)}</strong></p>
          `;
          menuItemsContainer.appendChild(menuItemDiv);
        });
      })
      .catch(err => console.error('Error fetching menu:', err));
  }
  
  function handleReservation(event) {
    event.preventDefault();
  
    const name = document.getElementById('name').value;
    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;
    const people = document.getElementById('people').value;
  
    const reservationData = { name, date, time, people };
  
    fetch('/api/reservation', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(reservationData),
    })
      .then(response => response.text())
      .then(message => {
        const statusDiv = document.getElementById('reservation-status');
        statusDiv.textContent = message;
      })
      .catch(err => {
        console.error('Error making reservation:', err);
      });
  }
  