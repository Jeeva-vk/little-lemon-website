const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const port = 3000;

// Serve static files from the 'frontend' directory
app.use(express.static(path.join(__dirname, '../frontend')));

// Mock database for menu items
const menuPath = path.join(__dirname, 'menu.json');
const getMenu = () => JSON.parse(fs.readFileSync(menuPath));

// Endpoint to get menu
app.get('/api/menu', (req, res) => {
  const menu = getMenu();
  res.json(menu);
});

// Endpoint to handle reservations
app.post('/api/reservation', express.json(), (req, res) => {
  const { name, date, time, people } = req.body;
  if (!name || !date || !time || !people) {
    return res.status(400).send('Missing reservation information');
  }
  // For simplicity, let's assume the reservation is always successful
  res.status(200).send(`Reservation for ${name} on ${date} at ${time} for ${people} people is confirmed.`);
});

// Start the server
app.listen(port, () => {
  console.log(`Little Lemon app running at http://localhost:${port}`);
});
